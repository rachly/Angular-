import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { User } from 'src/models/User';
import { UserService } from '../user.service';
//import {ConfirmValidation } from 'src/confirmValidation';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
   ngOnInit(): void {
  this.myForm=new FormGroup({
    "CodeU":new FormControl("",Validators.required),
    "NameU":new FormControl(""),
    "Adress":new FormControl(""),
    "Email":new FormControl("",Validators.compose([Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$‏'),Validators.required])),
    "password":new FormControl("",Validators.required),
    })
    
  }
  
myForm:FormGroup;
constructor(private UserS:UserService) { }
save(){
  var User=new User(this.myForm.value.CodeU,this.myForm.value.NameU,this.myForm.value.Adress,this.myForm.value.Email,this.myForm.value.password);
  this.UserS.register(User).subscribe(s=>{if(s==1)console.log(s)},e=>{console.log(e)})

  this.myForm.reset();

 }
}
