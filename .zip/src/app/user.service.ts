import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from 'src/models/User';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private Http:HttpClient ) { 

  }
   

register(User:User){
  return this.Http.post<number>("https://localhost:44314/api/User/AddUser",User);
 
}


}
