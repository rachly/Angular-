export class Category{
    constructor(public CodeC:number,public NameC:string,public NituvI:string){        
    }
}