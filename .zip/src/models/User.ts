export class User{
    constructor(public CodeU:number,public NameU:string,public Adress:string,public Email:string,public password:string){

    }
}