export class Recipe{

    constructor(public CodeR:number,public NameR:string,public CodeC:number,public Time:number,public Darga:number,public DataAdd:Date,public ListComponent:Array<string>,public preparationM:[],public CodeU:number,public image:string,public IfShow:boolean ){
        
    }
}